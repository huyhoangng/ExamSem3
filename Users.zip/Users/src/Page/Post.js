import React from 'react'
import PostForm from '../component/post/PosrForm'


const Post = () => {
  return (
    <div>
     <PostForm/>
    </div>
  )
}

export default Post