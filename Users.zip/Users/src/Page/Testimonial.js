import React from 'react'
import PageHeader from '../component/testimonials/PageHeader'
import Testimonials from '../component/testimonials/Testimonials'
const Testimonial = () => {
  return (
    <div>
      <PageHeader />
      <Testimonials />
    </div>
  )
}

export default Testimonial
