import React from 'react'
import PageHeader from '../component/blog/PageHeader'
import Article from '../component/blog/Article'

const Blog = () => {
  return (
    <div>
      <PageHeader />
      <Article />
    </div>
  )
}

export default Blog
