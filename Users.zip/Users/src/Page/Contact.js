import React from 'react'
import PageHeader from '../component/contact/PageHeader'
import ContactSection from '../component/contact/Contact'

const Contact = () => {
  return (
    <div>
      <PageHeader />
      <ContactSection />
    </div>
  )
}

export default Contact
