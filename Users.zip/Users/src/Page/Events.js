// src/Page/Events.js
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import EventList from '../component/events/EventList';
import PageHeader from '../component/eventDetail/PageHeader';

const Events = () => {
  return (
    <div>
      <PageHeader title="Events" subtitle="Explore our upcoming events and join us!" />
      <Routes>
        <Route path="/" element={<EventList />} />
      </Routes>
    </div>
  );
};

export default Events;
