import React from 'react'
import AboutUs from '../component/trangChu/AboutUs'
import Article from '../component/trangChu/Article'
import Carousel from '../component/trangChu/Carousel'
import JoinEvent from'../component/trangChu/JoinEvent'
import Testimonial from '../component/trangChu/Testimonial'
import Contact from '../component/trangChu/Contact'
import OurEvents from '../component/trangChu/OurEvents'


const Home = () => {
  return (
    <div>
      
      <Carousel />
    <AboutUs />
    <OurEvents />
    <Article />
    <JoinEvent />
    <Testimonial />
    <Contact />
    
    </div>
  )
}

export default Home
