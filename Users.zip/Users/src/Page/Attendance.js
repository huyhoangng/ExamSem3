import React from 'react'
import Form from '../component/attend/Form'
import PageHeader from '../component/attend/PageHeader'

const Attendance = () => {
  return (
    <div>
      <PageHeader />
      <Form />
      
    </div>
  )
}

export default Attendance
