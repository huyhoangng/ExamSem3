import React from 'react';

const Store = () => {
    const products = [
        {
            id: 1,
            name: "A Beach Clean Up Day",
            description: "A community initiative focused on preserving coastal environments by gathering volunteers to remove litter and debris, promoting environmental awareness, and fostering a cleaner, healthier shoreline.",
            size: "Small",
            image: "img/store-product-1.jpg",
            delay: "0.1s"
        },
        {
            id: 2,
            name: "Save Our Forest",
            description: "A conservation project aimed at protecting and restoring forest ecosystems. It involves community-driven efforts to prevent deforestation, promote reforestation, and raise awareness about the importance of preserving natural habitats",
            size: "Medium",
            image: "img/store-product-2.jpg",
            delay: "0.3s"
        },
        {
            id: 3,
            name: "For Clean Air",
            description: "An environmental campaign dedicated to reducing air pollution by promoting sustainable practices, advocating for cleaner energy sources, and raising public awareness to ensure a healthier atmosphere for all.",
            size: "Big",
            image: "img/store-product-3.jpg",
            delay: "0.5s"
        },
    ];

    return (
        <div className="container-xxl py-5">
            <div className="container">
                <div className="section-title text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style={{ maxWidth: '500px' }}>
                    <p className="fs-5 fw-medium fst-italic text-primary">Helpful advice</p>
                    <h1 className="display-6">You want to distinguish waste most accurately?</h1>
                </div>
                <div className="row g-4">
                    {products.map((product) => (
                        <div key={product.id} className="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay={product.delay}>
                            <div className="store-item position-relative text-center">
                                <img className="img-fluid" src={product.image} alt={product.name} />
                                <div className="p-4">
                                    <div className="text-center mb-3">
                                        {[...Array(5)].map((_, i) => (
                                            <small key={i} className="fa fa-star text-primary"></small>
                                        ))}
                                    </div>
                                    <h4 className="mb-3">{product.name}</h4>
                                    <p>{product.description}</p>
                                    <h4 className="text-primary">{product.price}</h4>
                                </div>
                                <div className="store-overlay">
                                    
                                    <a href="/attendance" className="btn btn-dark rounded-pill py-2 px-4 m-2">Take part in with us <i className="fa fa-cart-plus ms-2"></i></a>
                                </div>
                            </div>
                        </div>
                    ))}
                    <div className="col-12 text-center wow fadeInUp" data-wow-delay="0.1s">
                        <a href="/event" className="btn btn-primary rounded-pill py-3 px-5">View More Events</a>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Store;
