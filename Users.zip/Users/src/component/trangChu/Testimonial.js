import React from 'react';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";



const Testimonial = () => {
    const settings = {
        dots: true, // Hiển thị các chấm điều hướng
        infinite: true, // Vòng lặp vô tận
        speed: 500, // Tốc độ chuyển slide (nhanh hơn)
        slidesToShow: 3, // Số lượng slides hiển thị cùng lúc
        slidesToScroll: 1, // Số lượng slides cuộn mỗi lần
        autoplay: true, // Tự động chuyển slide
        autoplaySpeed: 2000, // Tốc độ tự động chuyển slide (nhanh hơn)
        centerMode: true, // Hiển thị slide ở chính giữa
        centerPadding: '0px', // Padding cho slide trung tâm
        arrows: true, // Hiển thị các nút điều hướng ở hai bên
        responsive: [
          {
            breakpoint: 768,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
              centerMode: false, // Tắt chế độ centerMode trên màn hình nhỏ
            },
          },
        ],
      };
    const testimonials = [
        {
            id: 1,
            text: 'These projects demonstrate exceptional commitment to environmental sustainability, fostering positive change for our planet future',
            image: 'img/testimonial-1.jpg',
            name: 'Nguyen Huy Hoang',
            profession: 'Founder',
        },
        {
            id: 2,
            text: 'Remarkable initiatives that exemplify proactive environmental stewardship and inspire communities to take meaningful action',
            image: 'img/testimonial-4.png',
            name: 'Đang Ngoc Anh',
            profession: 'Doctor',
        },
        {
            id: 3,
            text: 'Outstanding efforts in conservation and sustainability, setting a high standard for environmental protection',
            image: 'img/testimonial-3.png',
            name: 'Đang Cong Thanh',
            profession: 'Profession',
        },
    ];

    return (
        <div className="container-fluid testimonial py-5 my-5">
            <div className="container py-5">
                <div className="section-title text-center mx-auto wow fadeInUp" style={{ maxWidth: '500px' }}>
                    <p className="fs-5 fw-medium fst-italic text-white">Testimonial</p>
                    <h1 className="display-6">What experts say about our project</h1>
                </div>
                <Slider {...settings}
                    className="owl-carousel testimonial-carousel wow fadeInUp"
                    items={1}
                    margin={30}
                    loop
                    nav
                    dots
                    autoplay
                    autoplayTimeout={5000}
                >
                    {testimonials.map((testimonial) => (
                        <div key={testimonial.id} className="testimonial-item p-4 p-lg-5">
                            <p className="mb-4">{testimonial.text}</p>
                            <div className="d-flex align-items-center justify-content-center">
                                <img className="img-fluid flex-shrink-0" src={testimonial.image} alt={testimonial.name} />
                                <div className="text-start ms-3">
                                    <h5>{testimonial.name}</h5>
                                    <span className="text-primary">{testimonial.profession}</span>
                                </div>
                            </div>
                        </div>
                    ))}
                </Slider>
            </div>
        </div>
    );
};

export default Testimonial;
