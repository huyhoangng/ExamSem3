import React from 'react';

import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from 'react-slick';

const Testimonials = () => {
    const settings = {
        dots: true, // Hiển thị các chấm điều hướng
        infinite: true, // Vòng lặp vô tận
        speed: 500, // Tốc độ chuyển slide (nhanh hơn)
        slidesToShow: 3, // Số lượng slides hiển thị cùng lúc
        slidesToScroll: 1, // Số lượng slides cuộn mỗi lần
        autoplay: true, // Tự động chuyển slide
        autoplaySpeed: 2000, // Tốc độ tự động chuyển slide (nhanh hơn)
        centerMode: true, // Hiển thị slide ở chính giữa
        centerPadding: '0px', // Padding cho slide trung tâm
        arrows: true, // Hiển thị các nút điều hướng ở hai bên
        responsive: [
          {
            breakpoint: 768,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
              centerMode: false, // Tắt chế độ centerMode trên màn hình nhỏ
            },
          },
        ],
      };
    return (
        <div className="container-fluid py-5">
            <div className="container">
                <div className="section-title text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style={{ maxWidth: "500px" }}>
                    <p className="fs-5 fw-medium fst-italic text-primary">Testimonial</p>
                    <h1 className="display-6">What experts say about our project</h1>
                </div>
                <Slider {...settings} className="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.5s" loop margin={10} nav>
                    <div className="testimonial-item p-4 p-lg-5">
                        <p className="mb-4">These projects demonstrate exceptional commitment to environmental sustainability, fostering positive change for our planet future</p>
                        <div className="d-flex align-items-center justify-content-center">
                            <img className="img-fluid flex-shrink-0" src="img/testimonial-1.jpg" alt="Client 1" />
                            <div className="text-start ms-3">
                                <h5>Nguyen Huy Hoang</h5>
                                <span className="text-primary">Founder</span>
                            </div>
                        </div>
                    </div>
                    <div className="testimonial-item p-4 p-lg-5">
                        <p className="mb-4">Remarkable initiatives that exemplify proactive environmental stewardship and inspire communities to take meaningful action</p>
                        <div className="d-flex align-items-center justify-content-center">
                            <img className="img-fluid flex-shrink-0" src="img/testimonial-2.jpg" alt="Client 2" />
                            <div className="text-start ms-3">
                                <h5>Nguyen Duc Minh</h5>
                                <span className="text-primary">Profession</span>
                            </div>
                        </div>
                    </div>
                    <div className="testimonial-item p-4 p-lg-5">
                        <p className="mb-4">Outstanding efforts in conservation and sustainability, setting a high standard for environmental protection</p>
                        <div className="d-flex align-items-center justify-content-center">
                            <img className="img-fluid flex-shrink-0" src="img/testimonial-3.png" alt="Client 3" />
                            <div className="text-start ms-3">
                                <h5> Dang Cong Thanh</h5>
                                <span className="text-primary">Profession</span>
                            </div>
                        </div>
                    </div>
                    <div className="testimonial-item p-4 p-lg-5">
                        <p className="mb-4">Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo</p>
                        <div className="d-flex align-items-center justify-content-center">
                            <img className="img-fluid flex-shrink-0" src="img/testimonial-4.png" alt="Client 3" />
                            <div className="text-start ms-3">
                                <h5>Dang Ngoc Anh</h5>
                                <span className="text-primary">Doctor</span>
                            </div>
                        </div>
                    </div>
                </Slider>
            </div>
        </div>
    );
};

export default Testimonials;
