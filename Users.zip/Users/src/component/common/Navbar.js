import React from 'react'
import { Link } from 'react-router-dom'
import logo from '../../Assets/img/logo.jpg'

var token = localStorage.getItem("token");

function logoutFun(){
    window.localStorage.removeItem("token");
    window.localStorage.removeItem("user");
    window.location.href= 'login'
}

function Navbar() {
    var auth = <a href="login" className="nav-item nav-link">Login</a>
    if(token != null){
    auth = <>
    <div className="nav-item dropdown">
        <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">Account</a>
        <div className="dropdown-menu bg-light rounded-0 m-0">
            <a href="account" className="dropdown-item">Account</a>
            <span onClick={()=>logoutFun()} href="#" className="dropdown-item">Logout</span>
        </div>
    </div>
    </>
    }
  return (
    <div>
       <div className="container-fluid bg-white sticky-top">
            <div className="container">
                <nav className="navbar navbar-expand-lg bg-white navbar-light py-2 py-lg-0">
                    <a href="index.html" className="navbar-brand">
                    <img className="img-fluid" src={logo} alt="Logo" />
                    </a>
                    <button 
                        type="button" 
                        className="navbar-toggler ms-auto me-0" 
                        data-bs-toggle="collapse" 
                        data-bs-target="#navbarCollapse"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarCollapse">
                        <div className="navbar-nav ms-auto">
                            <a href="/" className="nav-item nav-link">Home</a>
                            <a href="about" class="nav-item nav-link">About</a>

                            <a href="event" className="nav-item nav-link">Event</a>
                            <div className="nav-item dropdown">
                                <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                                <div className="dropdown-menu bg-light rounded-0 m-0">
                                    <a href="blog" className="dropdown-item">Blog Article</a>
                                    <a href="testimonial" className="dropdown-item">Testimonial</a>
                                    <a href="attendance" className="dropdown-item">Attendant</a>
                                    
                                    <a href='post' className='dropdown-item'>Post</a>
                                </div>
                            </div>
                            {/* {auth} */}
                            <a href="contact" className="nav-item nav-link">Contact</a>
                        </div>
                        <div className="border-start ps-4 d-none d-lg-block">
                            <button type="button" className="btn btn-sm p-0"><i className="fa fa-search"></i></button>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
  )
}

export default Navbar
