import React, { useState } from 'react';
import '../../Assets/css/postForm.css'; // Import file CSS
import {postMethodPayload} from '../../services/request'
import Swal from 'sweetalert2'
import {toast } from 'react-toastify';

async function addPost(event) {
  event.preventDefault();
  var payload = {
      "title": event.target.elements.title.value,
      "body": event.target.elements.content.value,
      "author": event.target.elements.author.value,
  }
  var res = await postMethodPayload('/api/post/public/create-or-update', payload)
  if (res.status < 300) {
      Swal.fire({
          title: "Thông báo",
          text: "Upload Post success!",
          preConfirm: () => {
              window.location.reload();
          }
      });
  } else {
      toast.error("Error!");
  }
}

function PostForm() {
  // Sử dụng useState để lưu trữ dữ liệu nhập vào
  const [post, setPost] = useState({
    author: '',
    date: '',
    content: ''
  });

  // Hàm xử lý khi có sự thay đổi trong các trường input
  const handleChange = (e) => {
    const { name, value } = e.target;
    setPost({
      ...post,
      [name]: value
    });
  };

  // Hàm xử lý khi submit form
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Post Data:', post);
    alert('Post submitted successfully!');
  };

  return (
    <div className="post-form-container">
      <h2>Post a New Article</h2>
      <form onSubmit={addPost}>
        {/* Tên người đăng */}
        <div className="input-container">
          <label htmlFor="author">Author Name:</label>
          <input
            type="text"
            name="author"
            required
          />
        </div>

        <div className="input-container">
          <label htmlFor="author">Title:</label>
          <input
            type="text"
            name="title"
            required
          />
        </div>

        {/* Phần viết bài */}
        <div className="input-container">
          <label htmlFor="content">Content:</label>
          <textarea
            name="content"
            required
            rows="5"
          />
        </div>

        <button type="submit" className="submit-button">Submit Post</button>
      </form>
    </div>
  );
}

export default PostForm;
