import React from 'react';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react'
import {getMethod} from '../../services/request'
const EventList = () => {
  const [items, setItems] = useState([]);
  useEffect(()=>{
    const getEvent = async() =>{
        var response = await getMethod('/api/event/public/findAll-list');
        var list = await response.json();
        setItems(list)
    };
    getEvent();
}, []);

console.log(items);

  return (
    <div className="container-xxl py-5">
      <div className="container">
        <div className="section-title text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style={{ maxWidth: '500px' }}>
          <p className="fs-5 fw-medium fst-italic text-primary">Helpful advice</p>
          <h1 className="display-6">You want to distinguish waste most accurately?</h1>
        </div>
        <div className="row g-4">
          {items.map((item) => (
            <div key={item.id} className="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
              <div className="store-item position-relative text-center">
                {/* <img className="img-fluid" src={item.image} alt={item.name} /> */}
                <span className='spngaybatdau'>Ngày bắt đầu: {item.startDate}</span>
                <span className='spngaybatdau'>Ngày kết thúc: {item.endDate}</span>
                <div className="p-4">
                  <div className="text-center mb-3">
                    {[...Array(5)].map((_, i) => (
                      <small key={i} className="fa fa-star text-primary"></small>
                    ))}
                  </div>
                  <h4 className="mb-3">{item.name}</h4>
                  <p>{item.description}</p>
                </div>
                <div className="store-overlay">
                  <Link to={`/event-detail/${item.id}`} className="btn btn-primary rounded-pill py-2 px-4 m-2">
                    More Detail <i className="fa fa-arrow-right ms-2"></i>
                  </Link>
                  <Link to="/attendance" className="btn btn-dark rounded-pill py-2 px-4 m-2">
                    Take part in with us <i className="fa fa-cart-plus ms-2"></i>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EventList;
