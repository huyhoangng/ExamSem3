import React from 'react';
import { useParams } from 'react-router-dom';
import { useState, useEffect } from 'react'
import {getMethod} from '../../services/request'
const DetailEvent = () => {
  const { id } = useParams();
  const [item, setItem] = useState(null);
  useEffect(()=>{
    const getEvent = async() =>{
        var response = await getMethod('/api/event/public/findById?id=' + id);
        var result = await response.json();
        setItem(result)
    };
    getEvent();
}, []);

  // Mock data for demonstration purposes
  const events = [
    { id: 1, name: "Green Sunday", description: "A community initiative...", date: "August 15, 2024", location: "Beachside Park", image: "img/store-product-1.jpg", contact: "contact@greensunday.com" },
    { id: 2, name: "Green Summer", description: "A conservation project...", date: "September 10, 2024", location: "Woodland Reserve", image: "img/store-product-2.jpg", contact: "contact@greensummer.com" },
    { id: 3, name: "Clean City", description: "An environmental campaign...", date: "October 5, 2024", location: "Downtown Square", image: "img/store-product-3.jpg", contact: "contact@cleancity.com" }
  ];
  
  const event = events.find(event => event.id === parseInt(id));
  console.log(item);
  

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-lg-8">
          <div className="card shadow-sm">
            {/* <img src={item.image} className="card-img-top" alt={item.name} /> */}
            <div className="card-body">
              <h3 className="card-title text-center">{item==null?'':item.name}</h3>
              <p className="text-muted text-center">
                <i className="fas fa-calendar-alt"></i> {item==null?'':item.startDate} &nbsp; | &nbsp;
                <i className="fas fa-map-marker-alt"></i> {item==null?'':item.endDate}
              </p>
              <hr />
              <p className="card-text" dangerouslySetInnerHTML={{__html: item==null?'':item.content}}></p>
              <div className="text-center my-4">
                <h5 className="fw-bold">Event Details:</h5>
                <ul className="list-unstyled">
                  
                  <li><strong>Contact:</strong> {event?.contact}</li>
                </ul>
              </div>
              <div className="text-center">
                <a href={'/attendance?id='+(item==null?'':item.id)}>
                  <button className="btn btn-primary btn-lg px-4">
                    Join Event
                  </button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DetailEvent;
