import React, { useEffect, useState } from "react";
import { getMethod } from "../../services/request";

const Article = () => {
  const [posts, setPosts]= useState([])
 useEffect (()=>{
  (async()=>{
    const response = await getMethod('/api/post/public/approved')
    const posts = await response.json();
    setPosts(posts);
   })()
 },[])
  return (
    <div className="container-xxl py-5">
      <div className="container">
        <div className="row g-5">
          <div className="col-lg-5 wow fadeIn" data-wow-delay="0.1s">
            <img className="img-fluid" src="" alt="" />
          </div>
          {posts.map(post => (
            <div key={post.id} className="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
            <div className="section-title">
              <p className="fs-5 fw-medium fst-italic text-primary">{post.title}</p>
              <h1 className="display-6">{post.author}</h1>
            </div>
            <p className="mb-4">
            {post.body}
            </p>
            {/* <p className="mb-4">
              Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit,
              sed stet lorem sit clita duo justo magna. Tempor erat elitr rebum at clita.
            </p> */}
            <a href="#" className="btn btn-primary rounded-pill py-3 px-5">
              Read More
            </a>
          </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Article;
