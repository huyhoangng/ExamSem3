
import React , {useState} from 'react';
import { BrowserRouter as Router, Routes, Route , Link } from 'react-router-dom';
import Home from './Page/Home';
import Navbar from './component/common/Navbar';
import './Assets/css/bootstrap.min.css'
import './Assets/css/style.css'
import MainAbout from './Page/MainAbout';
import Events from './Page/Events';
import Footer from './component/common/Footer';
import Blog from './Page/Blog';
import Contact from './Page/Contact';
import CopyRight from './component/common/CopyRight';
import Testimonial from './Page/Testimonial';
import Attendance from './Page/Attendance';
import EventsDetail from './Page/EventsDetail';
import Lists from './Page/Lists';
import AdminLogin from './component/login/LoginForm';
import Post from './Page/Post';

function App() {
  const [registrations, setRegistrations] = useState([]);

  const handleRegister = (newEntry) => {
    setRegistrations([...registrations, newEntry]);
    console.log('Updated registrations:', registrations);
  };
  return (
    
    <Router>
<Navbar />
<main>
      <Routes>
      <Route path="/" element={<Home />} />
      <Route path='/about' element={<MainAbout />}/>
      <Route path='/event/*' element={<Events />}/>
      <Route path='/blog' element={<Blog />}/>
      <Route path='/contact' element={<Contact />}/>
      <Route path='/testimonial' element={<Testimonial />}/>
      <Route path='/event-detail/:id' element={<EventsDetail/>}/>
      <Route 
            path="/attendance" 
            element={<Attendance onRegister={handleRegister} />} 
          />
          <Route 
            path="/list" 
            element={<Lists registrations={registrations} />} 
          />
      <Route path='/login' element={<AdminLogin/>}/>
      <Route path='/post' element={<Post/>}/>
      </Routes>
</main>
<Footer />
<CopyRight />
    </Router>
  );
}

export default App;
