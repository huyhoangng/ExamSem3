package com.web.repository;

import com.web.entity.Event;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.sql.Date;
import java.util.List;

public interface EventRepository extends JpaRepository<Event, Long> {

    @Query("select e from Event e where e.startDate>=?1 and e.endDate <= ?2")
    public Page<Event> findByDate(Date from, Date to, Pageable pageable);

}
