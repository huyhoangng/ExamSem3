package com.web.repository;

import com.web.entity.EventRegistration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EventRegistrationRepository extends JpaRepository<EventRegistration, Long> {

    @Query("select e from EventRegistration e where e.event.id = ?1")
    public List<EventRegistration> findByEvent(Long eventId);
}
