package com.web.repository;

import com.web.entity.Post;
import com.web.entity.PostStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface PostRepository extends JpaRepository<Post, Long> {

    @Query("select p from Post p where p.user.id = ?1")
    public List<Post> myPost(Long userId);

    @Query("select p from Post p where p.postStatus = ?1")
    public List<Post> findByPostStatus(PostStatus postStatus);
}
