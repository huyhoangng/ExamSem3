package com.web.service;

import com.web.entity.Event;
import com.web.entity.Post;
import com.web.entity.PostStatus;
import com.web.entity.User;
import com.web.repository.EventRepository;
import com.web.repository.PostRepository;
import com.web.utils.MessageException;
import com.web.utils.UserUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class PostService {

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private UserUtils userUtils;

    public Post saveOrUpdate(Post post) {
        User user = userUtils.getUserWithAuthority();
        if(post.getId() != null){
            Post ex = postRepository.findById(post.getId()).get();
           if(user.getId() != ex.getUser().getId()){
               throw new MessageException("Bạn không đủ quyền");
           }
           post.setPostStatus(ex.getPostStatus());
           post.setCreatedAt(ex.getCreatedAt());
        }
        else{
            post.setCreatedAt(LocalDateTime.now());
            post.setPostStatus(PostStatus.CHUA_DUYET);
        }
        post.setUser(user);
        postRepository.save(post);
        return post;
    }


    public Post saveByPublicUser(Post post) {
        post.setCreatedAt(LocalDateTime.now());
        post.setPostStatus(PostStatus.CHUA_DUYET);
        postRepository.save(post);
        return post;
    }

    public void delete(Long id) {
        postRepository.deleteById(id);
    }

    public Post findById(Long id) {
        return postRepository.findById(id).get();
    }

    public List<Post> findApproved(){
        List<Post> list = postRepository.findByPostStatus(PostStatus.DA_DUYET);
        return list;
    }

    public Post updateStatus(Long id, PostStatus postStatus) {
        Post post = postRepository.findById(id).get();
        post.setPostStatus(postStatus);
        postRepository.save(post);
        return post;
    }

    public List<Post> findAll(){
        List<Post> list = postRepository.findAll();
        return list;
    }

    public List<Post> myPost(){
        User user = userUtils.getUserWithAuthority();
        List<Post> list = postRepository.myPost(user.getId());
        return list;
    }

    public Page<Post> findAll(Pageable pageable){
        Page<Post> page = postRepository.findAll(pageable);
        return page;
    }


}
