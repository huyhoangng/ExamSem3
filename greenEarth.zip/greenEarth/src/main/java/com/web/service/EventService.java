package com.web.service;

import com.web.entity.Event;
import com.web.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    public Event saveOrUpdate(Event event) {
        event.setCreatedAt(LocalDateTime.now());
        eventRepository.save(event);
        return event;
    }

    public void delete(Long id) {
        eventRepository.deleteById(id);
    }

    public Event findById(Long id) {
        return eventRepository.findById(id).get();
    }

    public List<Event> findAll(){
        List<Event> list = eventRepository.findAll();
        return list;
    }

    public Page<Event> findAll(Date from,Date to, Pageable pageable){
        Page<Event> page = null;
        if (from == null || to == null) {
            page = eventRepository.findAll(pageable);
        }

        else {
            page = eventRepository.findByDate(from, to, pageable);
        }
        return page;
    }
}
