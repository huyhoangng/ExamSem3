package com.web.service;

import com.web.entity.Event;
import com.web.entity.EventRegistration;
import com.web.repository.EventRegistrationRepository;
import com.web.repository.EventRepository;
import com.web.utils.MailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class EventRegistrationService {

    @Autowired
    private EventRegistrationRepository eventRegistrationRepository;

    @Autowired
    private MailService mailService;

    @Autowired
    private EventRepository eventRepository;

    public EventRegistration save(EventRegistration eventRegistration) {
        Event event = eventRepository.findById(eventRegistration.getEvent().getId()).get();
        eventRegistration.setCreatedAt(LocalDateTime.now());
        eventRegistrationRepository.save(eventRegistration);
        mailService.sendEmail(eventRegistration.getEmail(), "Thông báo đăng ký sự kiện",
                "Chúc mừng bạn đã đăng ký sự kiện "+event.getName()+" thành công<br>Thời gian đăng ký: "+LocalDateTime.now()
                , false, true);
        return eventRegistration;
    }

    public List<EventRegistration> findByEvent(Long eventId){
        List<EventRegistration> list = eventRegistrationRepository.findByEvent(eventId);
        return list;
    }

    public List<EventRegistration> findAll(){
        List<EventRegistration> list = eventRegistrationRepository.findAll();
        return list;
    }

    public Page<EventRegistration> findAll(Pageable pageable){
        Page<EventRegistration> page = eventRegistrationRepository.findAll(pageable);
        return page;
    }

    public void delete(Long id) {
        eventRegistrationRepository.deleteById(id);
    }
}
