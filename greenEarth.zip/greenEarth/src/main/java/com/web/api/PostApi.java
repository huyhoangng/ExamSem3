package com.web.api;

import com.web.entity.Event;
import com.web.entity.Post;
import com.web.entity.PostStatus;
import com.web.service.EventService;
import com.web.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/api/post")
@CrossOrigin
public class PostApi {

    @Autowired
    private PostService postService;

    @PostMapping("/all/create-or-update")
    public ResponseEntity<?> save(@RequestBody Post post){
        Post result = postService.saveOrUpdate(post);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

    @PostMapping("/public/create-or-update")
    public ResponseEntity<?> saveByPublic(@RequestBody Post post){
        Post result = postService.saveByPublicUser(post);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

    @DeleteMapping("/all/delete")
    public ResponseEntity<?> delete(@RequestParam("id") Long id){
        postService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/all/my-post")
    public ResponseEntity<?> myPost(){
        List<Post> result = postService.myPost();
        return new ResponseEntity<>(result,HttpStatus.OK);
    }

    @GetMapping("/admin/findAll-page")
    public ResponseEntity<?> findAllPage(Pageable pageable){
        Page<Post> result = postService.findAll(pageable);
        return new ResponseEntity<>(result,HttpStatus.OK);
    }


    @GetMapping("/public/findById")
    public ResponseEntity<?> findById(@RequestParam("id") Long id){
        Post result = postService.findById(id);
        return new ResponseEntity<>(result,HttpStatus.OK);
    }

    @PostMapping("/admin/update-status")
    public ResponseEntity<?> updateStatus(@RequestParam("id") Long id, @RequestParam PostStatus postStatus){
        Post result = postService.updateStatus(id, postStatus);
        return new ResponseEntity<>(result,HttpStatus.OK);
    }

    @GetMapping("/public/approved")
    public  ResponseEntity<?> findApproved(){
       List<Post>  result = postService.findApproved();
        return new ResponseEntity<>(result,HttpStatus.OK);
    }

}
