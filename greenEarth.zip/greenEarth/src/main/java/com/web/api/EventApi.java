package com.web.api;

import com.web.entity.Event;
import com.web.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.List;

@Controller
@RequestMapping("/api/event")
@CrossOrigin
public class EventApi {

    @Autowired
    private EventService eventService;

    @PostMapping("/admin/create-or-update")
    public ResponseEntity<?> save(@RequestBody Event event){
        Event result = eventService.saveOrUpdate(event);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

    @DeleteMapping("/admin/delete")
    public ResponseEntity<?> delete(@RequestParam("id") Long id){
        eventService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/public/findAll-list")
    public ResponseEntity<?> findAllList(){
        List<Event> result = eventService.findAll();
        return new ResponseEntity<>(result,HttpStatus.OK);
    }

    @GetMapping("/public/findAll-page")
    public ResponseEntity<?> findAllPage(@RequestParam(value = "from", required = false) Date from,
                                         @RequestParam(value = "to", required = false) Date to,Pageable pageable){
        Page<Event> result = eventService.findAll(from, to,pageable);
        return new ResponseEntity<>(result,HttpStatus.OK);
    }


    @GetMapping("/public/findById")
    public ResponseEntity<?> findById(@RequestParam("id") Long id){
        Event result = eventService.findById(id);
        return new ResponseEntity<>(result,HttpStatus.OK);
    }


}
