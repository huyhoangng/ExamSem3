package com.web.api;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.web.dto.*;
import com.web.entity.User;
import com.web.jwt.JwtTokenProvider;
import com.web.repository.UserRepository;
import com.web.service.GoogleOAuth2Service;
import com.web.service.UserService;
import com.web.utils.Contains;
import com.web.utils.MessageException;
import com.web.utils.UserUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Date;
import java.util.Optional;

@Controller
@RequestMapping("/api/user")
@CrossOrigin
public class UserApi {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private UserUtils userUtils;

    @Autowired
    private GoogleOAuth2Service googleOAuth2Service;

    @Autowired
    private UserService userService;

    @PostMapping("/login/google")
    public ResponseEntity<?> loginWithGoogle(@RequestBody String credential) throws Exception {
        GoogleIdToken.Payload payload = googleOAuth2Service.verifyToken(credential);
        if(payload == null){
            throw new MessageException("Đăng nhập thất bại");
        }
        TokenDto tokenDto = userService.loginWithGoogle(payload);
        return new ResponseEntity(tokenDto, HttpStatus.OK);
    }


    @PostMapping("/login/email")
    public ResponseEntity<?> authenticate(@RequestBody LoginDto loginDto) throws Exception {
        Optional<User> users = userRepository.findByUsernameAndPassword(loginDto.getUsername(), loginDto.getPassword());
        if(users.isEmpty()){
            throw new MessageException("Đăng nhập thất bại");
        }
        // check infor user
        if(users.get().getActived() == false){
            throw new MessageException("Tài khoản đã bị khóa");
        }
        CustomUserDetails customUserDetails = new CustomUserDetails(users.get());
        String token = jwtTokenProvider.generateToken(customUserDetails);
        TokenDto tokenDto = new TokenDto();
        tokenDto.setToken(token);
        tokenDto.setUser(users.get());
        return new ResponseEntity<>(tokenDto, HttpStatus.OK);
    }

    @GetMapping("/admin/check-role-admin")
    public ResponseEntity<?> checkRoleAdmin(){
        System.out.println("admin");
        return new ResponseEntity<>("success", HttpStatus.ACCEPTED);
    }

    @GetMapping("/user/check-role-user")
    public ResponseEntity<?> checkRoleUser(){
        System.out.println("user");
        return new ResponseEntity<>("success", HttpStatus.ACCEPTED);
    }


    @GetMapping("/admin/getUserByRole")
    public ResponseEntity<?> getUserNotAdmin(@RequestParam(value = "role", required = false) String role) {
        if(role == null){
            return new ResponseEntity<>(userRepository.findAll(), HttpStatus.ACCEPTED);
        }
        return new ResponseEntity<>(userRepository.getUserByRole(role), HttpStatus.ACCEPTED);
    }

    @GetMapping("/user/get-user-by-id")
    public ResponseEntity<?> findById(@RequestParam Long id) {
        User user = userRepository.findById(id).get();
        return new ResponseEntity<>(user, HttpStatus.ACCEPTED);
    }

    @GetMapping("/user/userlogged")
    public ResponseEntity<?> userlogged() {
        User user = userUtils.getUserWithAuthority();
        return new ResponseEntity<>(user, HttpStatus.ACCEPTED);
    }

    @PostMapping("/admin/lockOrUnlockUser")
    public ResponseEntity<?> activeOrUnactiveUser(@RequestParam("id") Long id){
        User user = userRepository.findById(id).get();
        if(user.getActived() == true){
            user.setActived(false);
            userRepository.save(user);
        }
        else{
            user.setActived(true);
            userRepository.save(user);
        }
        return new ResponseEntity<>("success", HttpStatus.ACCEPTED);
    }

    @PostMapping("/admin/addaccount")
    public ResponseEntity<?> addaccount(@RequestBody User user) {
        User result = userService.createUser(user);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }
}
