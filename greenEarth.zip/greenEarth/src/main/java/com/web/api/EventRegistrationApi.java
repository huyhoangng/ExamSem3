package com.web.api;

import com.web.entity.Event;
import com.web.entity.EventRegistration;
import com.web.service.EventRegistrationService;
import com.web.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/api/event-registration")
@CrossOrigin
public class EventRegistrationApi {

    @Autowired
    private EventRegistrationService eventRegistrationService;

    @PostMapping("/public/create")
    public ResponseEntity<?> save(@RequestBody EventRegistration eventRegistration){
        EventRegistration result = eventRegistrationService.save(eventRegistration);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

    @DeleteMapping("/admin/delete")
    public ResponseEntity<?> delete(@RequestParam("id") Long id){
        eventRegistrationService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/admin/findAll-list")
    public ResponseEntity<?> findAllList(){
        List<EventRegistration> result = eventRegistrationService.findAll();
        return new ResponseEntity<>(result,HttpStatus.OK);
    }

    @GetMapping("/admin/find-by-event")
    public ResponseEntity<?> findByEvent(@RequestParam Long eventId){
        List<EventRegistration> result = eventRegistrationService.findByEvent(eventId);
        return new ResponseEntity<>(result,HttpStatus.OK);
    }

    @GetMapping("/admin/findAll-page")
    public ResponseEntity<?> findAllPage(Pageable pageable){
        Page<EventRegistration> result = eventRegistrationService.findAll(pageable);
        return new ResponseEntity<>(result,HttpStatus.OK);
    }


}
