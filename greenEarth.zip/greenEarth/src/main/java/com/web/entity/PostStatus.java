package com.web.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum PostStatus {

    CHUA_DUYET, DA_DUYET, VI_PHAM
}
