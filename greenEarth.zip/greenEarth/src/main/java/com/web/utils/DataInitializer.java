package com.web.utils;

import com.web.entity.User;
import com.web.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.sql.Date;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        String username = "admin";
        String password = "admin";

        // Kiểm tra xem tài khoản đã tồn tại chưa
        if (!userRepository.findByUsername(username).isPresent()) {
            User user = new User();
            user.setUsername(username);
            user.setPassword(password);
            user.setActived(true);
            user.setCreatedDate(new Date(System.currentTimeMillis()));
            user.setRole("ROLE_ADMIN");
            // Nếu cần mã hóa mật khẩu, bạn có thể làm ở đây
            userRepository.save(user);
        }
    }
}
