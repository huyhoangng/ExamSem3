import layoutAdmin from '../layout/Layout'
import emptyLayout from '../layout/EmptyLayout'

//admin
import homeAdmin from '../pages/index'
import userAdmin from '../pages/user'
import sukien from '../pages/sukien'
import baipost from '../pages/baipost'
import addPost from '../pages/addpost'
import addEvent from '../pages/addevent'
import login from '../pages/login'
import eventregis from '../pages/eventregis'



const adminRoutes = [
    { path: "/login", component: login, layout: emptyLayout},
    { path: "/", component: login, layout: emptyLayout},
    { path: "/admin/index", component: homeAdmin, layout: layoutAdmin },
    { path: "/admin/user", component: userAdmin, layout: layoutAdmin },
    { path: "/admin/su-kien", component: sukien, layout: layoutAdmin },
    { path: "/admin/bai-post", component: baipost, layout: layoutAdmin },
    { path: "/admin/add-post", component: addPost, layout: layoutAdmin },
    { path: "/admin/add-event", component: addEvent, layout: layoutAdmin },
    { path: "/admin/event-regis", component: eventregis, layout: layoutAdmin },
];



export {adminRoutes};
