import { useState, useEffect } from 'react'
import ReactPaginate from 'react-paginate';
import {toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import $ from 'jquery'; 
import Swal from 'sweetalert2'
import {getMethod, postMethod, postMethodPayload} from '../services/request'
import DataTable from 'react-data-table-component';


var token = localStorage.getItem("token");

async function loadUser(role){
    var url = 'http://localhost:8080/api/user/admin/getUserByRole';
    if (role != "") {
        url += '?role=' + role
    }
    const response = await getMethod(url);
    return response;
}

async function handleAddAccount(event) {
    event.preventDefault();
    if(event.target.elements.password.value != event.target.elements.repassword.value){
        toast.error("Mật khẩu không trùng khớp");
        return;
    }
    const payload = {
        fullName: event.target.elements.fullname.value,
        username: event.target.elements.email.value,
        phone: event.target.elements.phone.value,
        password: event.target.elements.password.value
    };
    const res = await postMethodPayload('/api/user/admin/addaccount', payload)
    var result = await res.json()
    console.log(result);
    if (res.status == 417) {
        toast.error(result.defaultMessage);
    }
    if(res.status < 300){
        Swal.fire({
            title: "Thông báo",
            text: "Tạo tài khoản thành công!",
            preConfirm: () => {
                window.location.reload();
            }
        });
    }
};

const AdminUser = ()=>{
    const [items, setItems] = useState([]);
    useEffect(()=>{
        const getUser = async(role) =>{
            var response = await loadUser(role);
            var listUser = await response.json();
            setItems(listUser)
        };
        getUser("");
    }, []);


    async function filterUser(){
        var role = document.getElementById("role").value
        var response = await loadUser(role);
        var listUser = await response.json();
        setItems(listUser)
    }

    async function lockOrUnlock(id, type) {
        var con = window.confirm("Xác nhận hành động?");
        if (con == false) {
            return;
        }
        const response = await postMethod('/api/user/admin/lockOrUnlockUser?id=' + id)
        if (response.status < 300) {
            var mess = '';
            if (type == 1) {
                mess = 'Khóa thành công'
            } else {
                mess = 'Mở khóa thành công'
            }
            toast.success(mess);
            filterUser();
        } else {
            toast.error("Thất bại");
        }
    }
    

    const columns = [
        {name: 'ID',selector: row => row.id,sortable: true,},
        {name: 'Tên đăng nhập',selector: row => row.username, sortable: true,},
        {name: 'Họ tên',selector: row => row.fullName,sortable: true,},
        {name: 'Số điện thoại',selector: row => row.phone,sortable: true,},
        {name: 'Quyền',selector: row => row.role, sortable: true,},
        {
            name: 'Hành động',
            cell: row => (
                <div className="button-group">
                    {row.actived == true ? (<button onClick={()=>lockOrUnlock(row.id, 1)} className='btn btn-primary'>Khóa</button>) : 
                    (<button onClick={()=>lockOrUnlock(row.id, 0)} className='btn btn-danger'>Mở khóa</button>)}
                </div>
            ),
        },
      ];

    return (
        <>
            <div class="row">
                <div class="col-md-3 col-sm-6 col-6">
                    <label  class="lb-form" dangerouslySetInnerHTML={{__html:'&ThinSpace;'}}></label>
                    <a data-bs-toggle="modal" data-bs-target="#addtk" class="btn btn-primary"><i class="fa fa-plus"></i> Thêm admin</a>
                </div>
                <div class="col-md-3 col-sm-6 col-6">
                    <label class="lb-form">Chọn quyền</label>
                    <select onChange={()=>filterUser()} id='role' class="form-control">
                        <option value="">Tất cả quyền</option>
                        <option value="ROLE_USER">Tài khoản người dùng</option>
                        <option value="ROLE_ADMIN">Tài khoản admin</option>
                    </select>
                </div>
            </div>
            <div class="tablediv">
                <div class="headertable">
                    <span class="lbtable">Danh sách tài khoản</span>
                </div>
                <div class="divcontenttable">
                    <DataTable
                        columns={columns}
                        data={items}
                        pagination
                        highlightOnHover
                        striped
                    />
                </div>
            </div>

            <div class="modal fade" id="addtk" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="false">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Thêm tài khoản quản trị</h5> <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
                        <div class="modal-body row">
                            <form onSubmit={handleAddAccount} class="col-sm-6" style={{margin:'auto'}}>
                                <label class="lb-form">Họ tên</label>
                                <input name='fullname' id="fullname" class="form-control"/>
                                <label class="lb-form">Số điện thoại</label>
                                <input name='phone' id="phone" class="form-control"/>
                                <label class="lb-form">Email/ tên đăng nhập</label>
                                <input name='email' required id="email" class="form-control"/>
                                <label class="lb-form">Mật khẩu</label>
                                <input name='password' required id="pass" type="password" class="form-control"/>
                                <label class="lb-form">Nhắc lại mật khẩu</label>
                                <input name='repassword' required id="repass" type="password" class="form-control"/>
                                <br/>
                                <button class="form-control btn btn-primary">Thêm tài khoản</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default AdminUser;