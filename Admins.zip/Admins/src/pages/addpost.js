import { useState, useEffect } from 'react'
import ReactPaginate from 'react-paginate';
import {toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import $ from 'jquery'; 
import DataTable from 'datatables.net-dt';
import Swal from 'sweetalert2'
import {getMethod, postMethodPayload} from '../services/request';
import { formatMoney } from '../services/money';
import Select from 'react-select';
import { Editor } from '@tinymce/tinymce-react';
import React, { useRef } from 'react';

var description = '';
async function addOrUpdatePost(event) {
    event.preventDefault();
    var uls = new URL(document.URL)
    var id = uls.searchParams.get("id");
    var payload = {
        "id": id,
        "title": event.target.elements.tieude.value,
        "body": description,
    }
    var res = await postMethodPayload('/api/post/all/create-or-update', payload)
    if (res.status < 300) {
        Swal.fire({
            title: "Thông báo",
            text: "Thêm/cập nhật thành công!",
            preConfirm: () => {
                window.location.href = 'bai-post'
            }
        });
    } else {
        toast.error("Thêm/ sửa bài viết thất bại");
    }
}

const AdminAddPost = ()=>{
    const editorRef = useRef(null);
    const [item, setItem] = useState(null);
    const [textButton, setTextbutton] = useState("Thêm bài viết");

    useEffect(()=>{
        const getPost= async() =>{
            var uls = new URL(document.URL)
            var id = uls.searchParams.get("id");
            if(id != null){
                setTextbutton("Cập nhật bài viết")
                var response = await getMethod('/api/post/public/findById?id=' + id);
                var result = await response.json();
                setItem(result)
            }
        };
        getPost();
    }, []);

    function handleEditorChange(content, editor) {
        description = content;
    }
    return (
        <>
            <div className='row'>
                <div className='col-sm-4'>
                    <div className='headpageadmin'>
                        <span>{textButton}</span>
                    </div>
                </div>
            </div>
            <form className='row' onSubmit={addOrUpdatePost} method='post'>
            <div className='col-sm-8'>
                    <label className='lbadd-admin'>Tiêu đề bài viết</label>
                    <input name='tieude' defaultValue={item==null?'':item.title} className='form-control' required/>

                    <label className='lbadd-admin'>Nội dung bài viết</label>
                    <Editor name='editor' tinymceScriptSrc={'https://cdn.tiny.cloud/1/f6s0gxhkpepxkws8jawvfwtj0l9lv0xjgq1swbv4lgcy3au3/tinymce/6/tinymce.min.js'}
                        onInit={(evt, editor) => editorRef.current = editor} 
                        initialValue={item==null?'':item.body}
                        onEditorChange={handleEditorChange}/>
                    <label className='lbadd-admin' dangerouslySetInnerHTML={{__html:'&ThinSpace;'}}></label>
                    <button className='btn btn-primary form-control'>{textButton}</button>
                </div>
            </form>
        </>
    );
}

export default AdminAddPost;