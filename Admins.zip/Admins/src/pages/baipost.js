import { useState, useEffect } from 'react'
import ReactPaginate from 'react-paginate';
import {toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import $ from 'jquery'; 
import DataTable from 'datatables.net-dt';
import Swal from 'sweetalert2'
import {getMethod, deleteMethod, postMethod} from '../services/request';


var token = localStorage.getItem("token");


var size = 10
const AdminPost = ()=>{
    const [items, setItems] = useState([]);
    const [pageCount, setpageCount] = useState(0);
    useEffect(()=>{
        const getPost= async() =>{
            var response = await getMethod('/api/post/admin/findAll-page?page=0&size='+size+'&sort=id,desc');
            var result = await response.json();
            setItems(result.content)
            setpageCount(result.totalPages)
        };
        getPost();
    }, []);

    async function getAllPost(page) {
        var url = '/api/post/admin/findAll-page?page='+page+'&size='+size+'&sort=id,desc';
        var response = await getMethod(url);
        var result = await response.json();
        setItems(result.content)
        setpageCount(result.totalPages)
    }

    const handlePageClick = async (data)=>{
        var currentPage = data.selected
        await getAllPost(currentPage);
    }

    async function deletePost(id){
        var con = window.confirm("Bạn chắc chắn muốn xóa post này?");
        if (con == false) {
            return;
        }
        var url = '/api/post/all/delete?id=' + id;
        const response = await deleteMethod(url)
        if (response.status < 300) {
            toast.success("xóa thành công!");
            getAllPost(0);
        }
        if (response.status == 417) {
            var result = await response.json()
            toast.warning(result.defaultMessage);
        }
    }

    async function changeStatus(id, status){
        var url = '/api/post/admin/update-status?id=' + id+'&postStatus='+status;
        const response = await postMethod(url)
        if (response.status < 300) {
            toast.success("Thành công!");
        }
        if (response.status == 417) {
            var result = await response.json()
            toast.warning(result.defaultMessage);
        }
    }

    return (
        <>
            <div class="row header-page-admin">
                <div className='col-sm-3'>
                    <a className='btn btn-primary' href='add-post'>Thêm bài viết</a>
                </div>
            </div>
            <div class="tablediv">
                <div class="headertable">
                    <span class="lbtable">Danh sách lịch tiêm chủng</span>
                </div>
                <div class="divcontenttable">
                    <table id="example" class="table table-bordered">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Tiêu đề</th>
                                <th>Trạng thái</th>
                                <th>Người tạo</th>
                                <th>Ngày tạo</th>
                                <th>Chức năng</th>
                            </tr>
                        </thead>
                        <tbody>
                        {items.map((item, index)=>{
                            return <tr>
                                <td>{item.id}</td>
                                <td>{item.title}</td>
                                <td>
                                    <select onChange={(e)=>changeStatus(item.id,e.target.value)} className='form-control'>
                                        <option value={'CHUA_DUYET'} selected={item.postStatus == 'CHUA_DUYET'}>Chưa duyệt</option>
                                        <option value={'DA_DUYET'} selected={item.postStatus == 'DA_DUYET'}>Đã duyệt</option>
                                        <option value={'VI_PHAM'} selected={item.postStatus == 'VI_PHAM'}>Vi phạm</option>
                                    </select>
                                </td>
                                <td>{item.user?.username}</td>
                                <td>{item.createdAt}</td>
                                <td>
                                    <i onClick={()=>deletePost(item.id)} class="fa fa-trash iconaction"></i>
                                    <i onClick={()=>window.location.href='add-post?id='+item.id} class="fa fa-edit iconaction pointer"></i>
                                </td>
                            </tr>
                         })}
                        </tbody>
                    </table>
                    <ReactPaginate 
                        marginPagesDisplayed={2} 
                        pageCount={pageCount} 
                        onPageChange={handlePageClick}
                        containerClassName={'pagination'} 
                        pageClassName={'page-item'} 
                        pageLinkClassName={'page-link'}
                        previousClassName='page-item'
                        previousLinkClassName='page-link'
                        nextClassName='page-item'
                        nextLinkClassName='page-link'
                        breakClassName='page-item'
                        breakLinkClassName='page-link' 
                        previousLabel='Trang trước'
                        nextLabel='Trang sau'
                        activeClassName='active'/>

                </div>
            </div>

        </>
    );
}

export default AdminPost;