import { useState, useEffect } from 'react'
import ReactPaginate from 'react-paginate';
import {toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import $ from 'jquery'; 
import DataTable from 'datatables.net-dt';
import Swal from 'sweetalert2'
import {postMethodPayload} from '../services/request'

async function handleLogin(event) {
    event.preventDefault();
    const payload = {
        username: event.target.elements.username.value,
        password: event.target.elements.password.value
    };
    const res = await postMethodPayload('/api/user/login/email', payload);
    
    var result = await res.json()
    console.log(result);
    if (res.status == 417) {
        toast.warning(result.defaultMessage);
    }
    if(res.status < 300){
        toast.success('Đăng nhập thành công!');
        await new Promise(resolve => setTimeout(resolve, 1500));
        localStorage.setItem("token", result.token);
        localStorage.setItem("user", JSON.stringify(result.user));
        if (result.user.role === "ROLE_ADMIN") {
            window.location.href = 'admin/user';
        }
        else{
            toast.warning("Bạn đang đăng nhập với tài khoản có quyền khác admin");
        }
    }
};

const Login = ()=>{
    return (
        <div className="login-container">
        <h2>Đăng Nhập</h2>
        <form onSubmit={handleLogin} method='post'>
          <div className="input-group">
            <label>Email:</label>
            <input name='username' required />
          </div>
          <div className="input-group">
            <label>Mật khẩu:</label>
            <input name='password' type="password" required/>
          </div>
          <button type="submit">Đăng Nhập</button>
        </form>
      </div>
    );
}

export default Login;