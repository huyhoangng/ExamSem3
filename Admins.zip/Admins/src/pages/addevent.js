import { useState, useEffect } from 'react'
import ReactPaginate from 'react-paginate';
import {toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import $ from 'jquery'; 
import DataTable from 'datatables.net-dt';
import Swal from 'sweetalert2'
import {getMethod, postMethodPayload} from '../services/request';
import { formatMoney } from '../services/money';
import Select from 'react-select';
import AsyncSelect from 'react-select/async';
import { Editor } from '@tinymce/tinymce-react';
import React, { useRef } from 'react';

var description = '';
async function addOrUpdateSuKien(event) {
    event.preventDefault();
    var uls = new URL(document.URL)
    var id = uls.searchParams.get("id");
    var payload = {
        "id": id,
        "name": event.target.elements.tensukien.value,
        "startDate": event.target.elements.ngaybatdau.value,
        "endDate": event.target.elements.ngayketthuc.value,
        "content": description,
    }
    var res = await postMethodPayload('/api/event/admin/create-or-update', payload)
    if (res.status < 300) {
        Swal.fire({
            title: "Thông báo",
            text: "Thêm/cập nhật thành công!",
            preConfirm: () => {
                window.location.href = 'su-kien'
            }
        });
    } else {
        toast.error("Thêm/ sửa sự kiện thất bại");
    }
}

const AdminAddEvent = ()=>{
    const editorRef = useRef(null);
    const [item, setItem] = useState(null);
    const [textButton, setTextbutton] = useState("Thêm sự kiện");

    useEffect(()=>{
        const getSuKien= async() =>{
            var uls = new URL(document.URL)
            var id = uls.searchParams.get("id");
            if(id != null){
                setTextbutton("Cập nhật sự kiện")
                var response = await getMethod('/api/event/public/findById?id=' + id);
                var result = await response.json();
                setItem(result)
            }
        };
        getSuKien();
    }, []);

    function handleEditorChange(content, editor) {
        description = content;
    }

    return (
        <>
            <div className='row'>
                <div className='col-sm-4'>
                    <div className='headpageadmin'>
                        <span>{textButton}</span>
                    </div>
                </div>
            </div>
            <form className='row' onSubmit={addOrUpdateSuKien} method='post'>
                <div className='col-sm-4'>
                    <label className='lbadd-admin'>Tên sự kiện</label>
                    <input name='tensukien' defaultValue={item==null?'':item.name} className='form-control' required/>

                    <label className='lbadd-admin'>Ngày bắt đầu</label>
                    <input name='ngaybatdau' defaultValue={item==null?'':item.startDate} type='date' className='form-control' required/>

                    <label className='lbadd-admin'>Ngày kết thúc</label>
                    <input name='ngayketthuc' defaultValue={item==null?'':item.endDate} type='date' className='form-control' required/>
                    
                </div>
                <div className='col-sm-8'>
                    <label className='lbadd-admin'>Nội dung sự kiện</label>
                    <Editor name='editor' tinymceScriptSrc={'https://cdn.tiny.cloud/1/f6s0gxhkpepxkws8jawvfwtj0l9lv0xjgq1swbv4lgcy3au3/tinymce/6/tinymce.min.js'}
                        onInit={(evt, editor) => editorRef.current = editor} 
                        initialValue={item==null?'':item.content}
                        onEditorChange={handleEditorChange}/>
                    <label className='lbadd-admin' dangerouslySetInnerHTML={{__html:'&ThinSpace;'}}></label>
                    <button className='btn btn-primary form-control'>{textButton}</button>
                </div>
            </form>
        </>
    );
}

export default AdminAddEvent;