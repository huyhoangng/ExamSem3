import { useState, useEffect } from 'react'
import ReactPaginate from 'react-paginate';
import {toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import $ from 'jquery'; 
import Swal from 'sweetalert2'
import {getMethod, deleteMethod} from '../services/request';
import DataTable from 'react-data-table-component';
import Select from 'react-select';
var token = localStorage.getItem("token");


const AdminEventRegis = ()=>{
    const [items, setItems] = useState([]);
    const [events, setEvents] = useState([]);
    useEffect(()=>{
        const getRegis= async() =>{
            var response = await getMethod('/api/event-registration/admin/findAll-list');
            var list = await response.json();
            setItems(list)
        };
        getRegis();
        const getEvents= async() =>{
            var response = await getMethod('/api/event/public/findAll-list');
            var list = await response.json();
            setEvents(list)
        };
        getEvents();
    }, []);

    const handleChonLoai = async (option) => {
        var value = option.value;
        var response = await getMethod('/api/event-registration/admin/find-by-event?eventId='+value);
        var result = await response.json();
        setItems(result)
    };

    async function deleteDangKy(id){
        var con = window.confirm("Bạn chắc chắn muốn xóa đăng ký này?");
        if (con == false) {
            return;
        }
        var url = '/api/event-registration/admin/delete?id=' + id;
        var response = await deleteMethod(url)
        if (response.status < 300) {
            toast.success("xóa thành công!");
            var response = await getMethod('/api/event-registration/admin/findAll-list');
            var list = await response.json();
            setItems(list)
        }
        if (response.status == 417) {
            var result = await response.json()
            toast.warning(result.defaultMessage);
        }
    }

    const columns = [
        {name: 'Ngày đăng ký',selector: row => row.createdAt, sortable: true,},
        {name: 'Họ tên',selector: row => row.fullName, sortable: true,},
        {name: 'Email',selector: row => row.email, sortable: true,},
        {name: 'Số điện thoại',selector: row => row.phone,sortable: true,},
        {name: 'Tuổi',selector: row => row.ege, sortable: true,},
        {name: 'Sự kiện',selector: row => row.event.name, sortable: true,},
        {
            name: 'Hành động',
            cell: row => (
                    <button onClick={()=>deleteDangKy(row.id)} className='btn btn-primary'>Xóa</button>
            ),
        },
    ];
    
    return (
        <>
            <div class="row header-page-admin">
                <div className='col-sm-5'>
                    <Select
                        options={events.map((item) => ({
                            label: item.name,
                            value: item.id,
                        }))}
                        onChange={handleChonLoai}
                        placeholder="Chọn sự kiện"
                        name='centerselect'
                        isSearchable={true} 
                    />
                </div>
            </div>
            <div class="tablediv">
                <div class="headertable">
                    <span class="lbtable">Danh sách đăng ký sự kiện</span>
                </div>
                <div class="divcontenttable">
                    <DataTable
                        columns={columns}
                        data={items}
                        pagination
                        highlightOnHover
                        striped
                    />
                </div>
            </div>

        </>
    );
}

export default AdminEventRegis;