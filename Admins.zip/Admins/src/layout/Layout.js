import {handleChangePass} from '../services/auth'
import lich from '../assest/images/lich.png'
import avatar from '../assest/images/user.svg'
import { useState, useEffect } from 'react'

function Header({ children }){
    const [isCssLoaded, setCssLoaded] = useState(false);
    useEffect(()=>{
        import('../layout/layout.scss').then(() => setCssLoaded(true));
    }, []);
    if (!isCssLoaded) {
        return <></>
    }
    return(
        <>
         <div class="navleft" id="navleft">
            <div class="divroot">
                <h3>Quản trị</h3>
            </div>
            <div class="listmenumain">
                <a href="user">Tài khoản</a>
                <a href="bai-post">Bài post</a>
                <a href="su-kien">Sự kiện</a>
                <a href="event-regis">Đăng ký sự kiện</a>
                <a href="#" onClick={()=>logout()}>Đăng xuất</a>
            </div>
         </div>
    <div class="contentadminweb">
        <div class="headerwebadmin" id="headerwebadmin">
            <div class="lichheader">
                <img class="iconlich" src={lich} />
                <p class="text-gray fst-italic mb-0">
                    <p id="digital-clock"></p>
                </p>
            </div>
            <div class="userheader-admin">
                <a class="nav-link dropdown-toggle menucha" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <span class="tendangnhap">hieu</span>
                    <img src={avatar} className="userlogo-admin"/>
                </a>
                <ul class="dropdown-menu listitemtk" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" onClick={()=>logout()} href="#"><i class="fa fa-sign-out"></i> Đăng xuất</a></li>
                </ul>
            </div>
        </div>
        <div class="contentmain">
            {children}
        </div>
    </div>
        </>
    );
}

async function checkAdmin(){
    var token = localStorage.getItem("token");
    var url = 'http://localhost:8080/api/admin/check-role-admin';
    const response = await fetch(url, {
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if (response.status > 300) {
        window.location.replace('../login')
    }
}


function logout(){
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.replace('../login')
}

export default Header;