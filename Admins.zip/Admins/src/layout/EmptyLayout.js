import {handleChangePass} from '../services/auth'
import lich from '../assest/images/lich.png'
import avatar from '../assest/images/user.svg'
import { useState, useEffect } from 'react'

function EmptyLayout({ children }){
    const [isCssLoaded, setCssLoaded] = useState(false);
    useEffect(()=>{
        import('../layout/emptylayout.scss').then(() => setCssLoaded(true));
    }, []);
    if (!isCssLoaded) {
        return <></>
    }
    return(
        <>
            {children}
        </>
    );
}



export default EmptyLayout;