import { ToastContainer, toast } from 'react-toastify';
import {Routes, Route,BrowserRouter as Router} from 'react-router-dom'
import { adminRoutes } from './router/index';
import AdminLayout from './layout/Layout'

function App() {
  return (
    <Router>
      <div className="App">
          <Routes>


            {adminRoutes.map((route, index) => {
              const Layout = route.layout || AdminLayout
              const Page = route.component
              return <Route key={index} path={route.path} element={
                <Layout>
                  <Page/>
                </Layout>
              }/>
            })}


          </Routes>
      </div>
      <ToastContainer/>
    </Router>

);

}

export default App;
