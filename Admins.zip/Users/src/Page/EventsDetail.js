import React from 'react'
import DetailEvent from '../component/eventDetail/DetailEvent'
import PageHeader from '../component/eventDetail/PageHeader'

const EventsDetail = () => {
  return (
    <div>
        <PageHeader />
      <DetailEvent />
      
    </div>
  )
}

export default EventsDetail
