import React from 'react'
import RegistrationList from '../component/list/RegistrationList'
import PageHeader from '../component/list/PageHeader'

const Lists = () => {
  return (
    <div>
        <PageHeader />
      <RegistrationList />
    </div>
  )
}

export default Lists
