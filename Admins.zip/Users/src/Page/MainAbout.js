import React from 'react'
 import About from '../component/abouts/About'
import PageHeader from '../component/abouts/PageHeader'
const MainAbout = () => {
  return (
    <div>
      
      <PageHeader />
      <About />
    </div>
  )
}

export default MainAbout
