// src/Page/RegistrationList.js

import React from 'react';

const RegistrationList = ({ registrations = [] }) => { // Khởi tạo giá trị mặc định là mảng trống
  return (
    <div className="container mt-5">
      <h2 className="mb-4">List of Registered Participants</h2>
      {registrations.length === 0 ? (
        <p>No registrations yet.</p>
      ) : (
        <table className="table table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Age</th>
              <th>Address</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Event</th>
            </tr>
          </thead>
          <tbody>
            {registrations.map((registration) => (
              <tr key={registration.id}>
                <td>{registration.id}</td>
                <td>{registration.name}</td>
                <td>{registration.age}</td>
                <td>{registration.address}</td>
                <td>{registration.phone}</td>
                <td>{registration.email}</td>
                <td>{registration.event}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default RegistrationList;
