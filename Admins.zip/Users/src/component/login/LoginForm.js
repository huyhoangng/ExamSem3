import React, { useState } from 'react';
import '../../Assets/css/adminLogin.css'; // Import CSS hoặc bạn có thể dùng styled-components
import { GoogleOAuthProvider } from '@react-oauth/google';
import { GoogleLogin } from '@react-oauth/google';
import {toast } from 'react-toastify';

const AdminLogin = () => {
  const handleLoginSuccess = async (accessToken) => {
    console.log(accessToken);
    
    var response = await fetch('http://localhost:8080/api/user/login/google', {
        method: 'POST',
        headers: {
            'Content-Type': 'text/plain'
        },
        body: accessToken.credential
    })
    var result = await response.json();
    if (response.status < 300) {
        var user = result.user
        var token = result.token
        localStorage.setItem("token", token);
        localStorage.setItem("user", JSON.stringify(user));
        if (user.role === "ROLE_USER") {
            window.location.href = '/';
        }
    }
    if (response.status == 417) {
        toast.warning(result.defaultMessage);
    }
};

const handleLoginError = () => {
    toast.error("Đăng nhập google thất bại")
};

  
    return (
      <div className="admin-page"> 
        <div className="main-container">
          <div className="admin-login-container">
            <h2>Đăng nhập với tài khoản google</h2>
            <GoogleOAuthProvider clientId="663646080535-l004tgn5o5cpspqdglrl3ckgjr3u8nbf.apps.googleusercontent.com">
                    <div className='divcenter' style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                    <GoogleLogin
                        onSuccess={handleLoginSuccess}
                        onError={handleLoginError}
                    />
                    </div>
                    </GoogleOAuthProvider>
          </div>
        </div>
      </div>
    );
  };
  
  export default AdminLogin;