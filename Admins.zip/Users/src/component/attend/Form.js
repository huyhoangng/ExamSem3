// src/Page/Form.js

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import {useEffect } from 'react'
import {getMethod, postMethodPayload} from '../../services/request'
import Swal from 'sweetalert2'
import {toast } from 'react-toastify';

const Form = ({ onRegister }) => {
  const [item, setItem] = useState(null);
  useEffect(()=>{
    const getEvent = async() =>{
        var uls = new URL(document.URL)
        var id = uls.searchParams.get("id");
        var response = await getMethod('/api/event/public/findById?id=' + id);
        var result = await response.json();
        setItem(result)
    };
    getEvent();
    
}, []);


  const handleSubmit = async (event) => {
    event.preventDefault();
    var payload = {
      "email": event.target.elements.email.value,
      "fullName": event.target.elements.name.value,
      "ege": event.target.elements.age.value,
      "phone": event.target.elements.phone.value,
      "event": {
        "id": item.id
      },
    }
    console.log(payload);
    var res = await postMethodPayload('/api/event-registration/public/create', payload)
    if (res.status < 300) {
        Swal.fire({
            title: "Thông báo",
            text: "Đăng ký thành công!",
            preConfirm: () => {
                window.location.reload();
            }
        });
    } else {
        toast.error("Đăng ký thất bại");
    }
  };

  return (
    <div className="container form-container mt-5">
      <h2 className="mb-4">Event Registration Form</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Name:</label>
          <input 
            type="text" 
            id="name" 
            name="name" 
            className="form-control" 
            required 
          />
        </div>

        <div className="mb-3">
          <label htmlFor="age" className="form-label">Age:</label>
          <input type="number" 
            id="age" 
            name="age" 
            className="form-control" 
            required 
          />
        </div>

        <div className="mb-3">
          <label htmlFor="phone" className="form-label">Phone Number:</label>
          <input 
            type="tel" 
            id="phone" 
            name="phone" 
            className="form-control" 
            pattern="[0-9]{10}" 
            required 
          />
        </div>

        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email:</label>
          <input 
            type="email" 
            id="email" 
            name="email" 
            className="form-control" 
            required 
          />
        </div>
        <button type="submit" className="btn btn-primary">Register</button> 
      </form>
    </div>
  );
};

export default Form;

