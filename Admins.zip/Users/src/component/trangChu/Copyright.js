import React from 'react';

const Copyright = () => {
    return (
        <div className="container-fluid copyright py-4">
            <div className="container">
                <div className="row">
                    <div className="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a className="fw-medium" href="#">Your Site Name</a>, All Rights Reserved.
                    </div>
                    <div className="col-md-6 text-center text-md-end">
                        Designed By <a className="fw-medium" href="https://htmlcodex.com">HTML Codex</a>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Copyright;
