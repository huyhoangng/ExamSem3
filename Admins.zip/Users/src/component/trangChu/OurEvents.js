import React,{useEffect} from 'react';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from 'react-slick';

const OurEvents = () => {
  const settings = {
    dots: true, // Hiển thị các chấm điều hướng
    infinite: true, // Vòng lặp vô tận
    speed: 300, // Tốc độ chuyển slide
    slidesToShow: 3, // Số lượng slides hiển thị cùng lúc
    slidesToScroll: 1, // Số lượng slides cuộn mỗi lần
    autoplay: true, // Tự động chuyển slide
    autoplaySpeed: 3000, // Tốc độ tự động chuyển slide
    responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };
    return (
        
        <Slider {...settings} className="owl-carousel product-carousel wow fadeInUp" data-wow-delay="0.5s">
  <a href="/" className="d-block product-item rounded">
    <img src="img/product-1.jpg" alt="Green Tea" />
    <div className="bg-white shadow-sm text-center p-4 position-relative mt-n5 mx-4">
      <h4 className="text-primary">Forest</h4>
      <span className="text-body">
      Volunteers gathered in the forest to clean up trash, picking up litter scattered among the trees and trails. Their efforts helped restore the natural beauty of the area and protect wildlife from harmful waste.
      </span>
    </div>
  </a>
  <a href="/" className="d-block product-item rounded">
    <img src="img/product-4.jpg" alt="Black Tea" />
    <div className="bg-white shadow-sm text-center p-4 position-relative mt-n5 mx-4">
      <h4 className="text-primary">Sea</h4>
      <span className="text-body">
      Cleaning up trash on the beach is essential to protect marine life and preserve the natural beauty of the coastline.
      </span>
    </div>
  </a>
  <a href="/" className="d-block product-item rounded">
    <img src="img/product-2.jpg" alt="Spiced Tea" />
    <div className="bg-white shadow-sm text-center p-4 position-relative mt-n5 mx-4">
      <h4 className="text-primary">River</h4>
      <span className="text-body">
      Removing trash from the river is crucial for maintaining water quality, preserving the ecosystem, and preventing debris from flowing into larger bodies of water.
      </span>
    </div>
  </a>
  <a href="/" className="d-block product-item rounded">
    <img src="img/product-3.jpg" alt="Organic Tea" />
    <div className="bg-white shadow-sm text-center p-4 position-relative mt-n5 mx-4">
      <h4 className="text-primary">City</h4>
      <span className="text-body">
      Picking up litter in the city helps keep urban spaces clean and pleasant for everyone. It also reduces pollution and makes neighborhoods safer and more inviting.
      </span>
    </div>
  </a>
</Slider>

    );
  };

export default OurEvents;
