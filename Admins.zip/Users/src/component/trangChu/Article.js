import React from 'react';

const Article = () => {
    return (
        <div className="container-xxl py-5">
            <div className="container">
                <div className="row g-5">
                    {/* Image Column */}
                    <div className="col-lg-5 wow fadeIn" data-wow-delay="0.1s">
                        <img className="img-fluid" src="img/article.jpg" alt="" />
                    </div>

                    {/* Text Content Column */}
                    <div className="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                        <div className="section-title">
                            <p className="fs-5 fw-medium fst-italic text-primary">News</p>
                            <h1 className="display-6">The state of environmental pollution worldwide</h1>
                        </div>
                        <p className="mb-4">
                        The global environment is facing significant challenges, from climate change to deforestation and pollution. Rising temperatures are leading to more frequent and severe weather events, while deforestation is causing the loss of biodiversity and contributing to greenhouse gas emissions. 
                        </p>
                        <p className="mb-4">
                        Pollution, particularly from plastics and industrial waste, is contaminating oceans and rivers, harming wildlife, and threatening human health. To protect our planet, it is essential that we take urgent and collective action to reduce emissions, preserve natural habitats, and adopt sustainable practices in our daily lives.
                        </p>
                        <a href="/blog" className="btn btn-primary rounded-pill py-3 px-5">
                            Read More
                        </a>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Article;
